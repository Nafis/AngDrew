
export class LaClasse {
    constructor() {       
    }
}