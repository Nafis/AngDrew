import { LaClasse } from './la-classe';

describe('LaClasse', () => {
  it('should create an instance', () => {
    expect(new LaClasse()).toBeTruthy();
  });
});
