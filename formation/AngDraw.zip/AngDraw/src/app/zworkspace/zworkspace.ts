import { Component } from '@angular/core';

@Component({
  selector: 'app-zworkspace',
  standalone: false,
  templateUrl: './zworkspace.html',
  styleUrl: './zworkspace.scss',
})
export class ZWorkspace {

}
