import { Component } from '@angular/core';

@Component({
  selector: 'app-top-bar',
  standalone: false,
  templateUrl: './top-bar.html',
  styleUrl: './top-bar.scss',
})
export class TopBar {

}
