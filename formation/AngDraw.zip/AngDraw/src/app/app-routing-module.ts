import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageDessinInformation } from './page-dessin-information/page-dessin-information';

const routes: Routes = [
  {path:"", redirectTo:"dessininfo" , pathMatch:'full'},
  {path:"dessininfo" , component: PageDessinInformation},
  {path:"**", redirectTo:"dessininfo", pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
