export class LaClasse {
}
