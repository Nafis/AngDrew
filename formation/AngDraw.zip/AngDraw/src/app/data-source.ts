import { Injectable } from '@angular/core';
import { DessinType } from './model/dessin-type';
import { v4 } from 'uuid';

@Injectable({
  providedIn: 'root',
})
export class DataSource {
    private dessins: DessinType[] = [];

    addNewDessin(newDessin:DessinType): void {
      newDessin.id = v4().toString();
      console.log(newDessin.id);
      this.dessins.push(newDessin); // TODO gestion doublon
    }
   
    public get size() : number {
      return this.dessins.length;
    }

    getDessin(id: string) : DessinType {
      //return {id};
      return {id : id };
    }

    getAllDessins() : DessinType[] {
      return this.dessins;
    }

}
