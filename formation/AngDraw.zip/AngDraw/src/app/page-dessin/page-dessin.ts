import { Component } from '@angular/core';

@Component({
  selector: 'app-page-dessin',
  standalone: false,
  templateUrl: './page-dessin.html',
  styleUrl: './page-dessin.scss',
})
export class PageDessin {

}
