import { TestBed } from '@angular/core/testing';

import { DataSource } from './data-source';
import { DessinType } from './model/dessin-type';

describe('DataSource', () => {
  let service: DataSource;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataSource);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('add new DessinInfo', () => {
    const tempDessin: DessinType = new DessinType();
    service.addNewDessin(tempDessin);   
    expect(service.size).toEqual(1);
  });

  it('check size after created', () => {
    const tempDessin: DessinType = new DessinType();
    expect(service.size).toEqual(0);
  });
  
});
