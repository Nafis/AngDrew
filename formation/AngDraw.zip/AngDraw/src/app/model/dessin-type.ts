export class DessinType {
    id : string="";
    name?: string;
    author?: string;
    description?: string;    
}